<?php
wp_footer();
?>
