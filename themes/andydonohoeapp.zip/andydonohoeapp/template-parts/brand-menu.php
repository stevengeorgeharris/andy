<div class="header">
  <div class="header__brand">
    <a href="/">
      <span class="brand-main">Andy Donohoe</span>
      <span class="brand-sub">Photographer</span>
    </a>
  </div>

  <div class="header__menu-button header__menu-button--pop">
    <span class="bar-1"></span>
    <span class="bar-2"></span>
    <span class="bar-3"></span>
  </div>
</div>
