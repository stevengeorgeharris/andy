<div class="maintenance">
  <div class="maintenance-branding">
    <div class="maintenance-branding__container">
      <span class="maintenance-branding__main">
        Andy Donohoe
      </span>
      <span class="maintenance-branding__sub">
        Photographer
      </span>
      <span class="maintenance-branding__soon">
        Coming Soon
      </span>
    </div>
  </div>
</div>
