<div class="menu-pop">
  <div class="menu-pop__content">
    <div class="menu-pop__about">
      <?php the_field('about', 'option'); ?>
    </div>

  </div>
</div>
