<div class="welcome">
  <div class="welcome-branding">
    <div class="welcome-branding__container">
      <span class="welcome-branding__main">
        Andy Donohoe
      </span>
      <span class="welcome-branding__sub">
        Photographer
      </span>
    </div>
  </div>
</div>
